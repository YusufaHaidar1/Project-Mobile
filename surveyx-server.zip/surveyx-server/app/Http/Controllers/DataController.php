<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\LazyCollection;
use League\Csv\Reader;

class DataController extends Controller
{
    public function index()
    {
        $data = Reader::createFromPath(env('CSV_PATH'));
        $data->setHeaderOffset(0);
        $data = $data->getRecords();
        $citiesCollection = Collect($data)->values()->all();
        return response()->json($citiesCollection);
    }
}
