<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StudentComplaintSurvey extends Model
{
    use HasFactory;

    protected $fillable = [
        'NIM',
        's1',
        's2',
        's3',
        's4',
        's5',
        's6',
        's7',
        's8'
    ];
}