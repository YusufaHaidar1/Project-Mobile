<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\StudentComplaintSurvey;

class StudentComplaintSurveySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        StudentComplaintSurvey::truncate();
        
        $csvFile = fopen(base_path("database/data/StudentComplaintSurvey.csv"), "r");
  
        $firstline = true;
        while (($data = fgetcsv($csvFile, 1500, ",")) !== FALSE) {
            if (!$firstline) {
                StudentComplaintSurvey::create([
                    'NIM' => $data['0'],
                    's1' => $data['1'],
                    's2' => $data['2'],
                    's3' => $data['3'],
                    's4' => $data['4'],
                    's5' => $data['5'],
                    's6' => $data['6'],
                    's7' => $data['7'],
                    's8' => $data['8'],
                ]);    
            }
            $firstline = false;
        }
   
        fclose($csvFile);
    }
}