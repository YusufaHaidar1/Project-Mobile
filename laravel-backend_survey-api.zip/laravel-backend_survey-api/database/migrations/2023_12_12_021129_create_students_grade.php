<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStudentsGrade extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('students_grade', function (Blueprint $table) {
            $table->id();
            $table -> string('NIM')->unique();;
            $table -> float('s1');
            $table -> float('s2');
            $table -> float('s3');
            $table -> float('s4');
            $table -> float('s5');
            $table -> float('s6');
            $table -> float('s7');
            $table -> float('s8');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('students_grade');
    }
}
