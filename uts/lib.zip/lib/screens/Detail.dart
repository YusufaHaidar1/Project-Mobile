import 'package:flutter/material.dart';
import 'package:uts/screens/detail_complain.dart';

class Detail extends StatefulWidget{
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Detail>{
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail'),
        backgroundColor: Color(0xff151515),
        automaticallyImplyLeading: false,
      ),
      body: SafeArea(
        child: Container(
          padding: EdgeInsets.all(15),
          child: ListView(
            children: [
              SizedBox(height: 24,),
              Text(
                "Data UTS",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 12,),
              UTS(),
            ],
          ),
        ),
      ),
    );
  }

  Table UTS(){
    return Table(
      border: TableBorder(
        horizontalInside: BorderSide(
          width: 1,
          color: Colors.grey,
        ),
      ),
      children: [
        TableRow(
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical:12),
              child: Text(
                "Genre",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical:12),
              child: Text(
                "Report",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical:12),
              child: Text(
                "Detail",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ]
        ),
        TableRow(
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical:12),
              child: Text(
                "Serangan Finansial",
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical:12),
              child: Text(
                "Saya Miskin karena diri sendiri",
              ),
            ),
            TextButton( 
              child: Icon(
                Icons.chevron_right,
                color: Colors.grey,
              ),
              onPressed: (){
                Navigator.push(context,
                MaterialPageRoute(builder: (context)=> const DetailComplain())
                );
              },
            ),
          ]
        ),
      ],
    );
  }
}