import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:uts/screens/Detail.dart';

class Home extends StatelessWidget{
  const Home({super.key});
  @override

Widget build(BuildContext context){
  return Scaffold(
    appBar: AppBar(
        title: Text('Awal aja ini bang'),
        backgroundColor: Color(0xff151515),
    ),
    body: SingleChildScrollView(
      padding: const EdgeInsets.all(8),
      scrollDirection: Axis.vertical,
      child: Column(
        children: <Widget>[
          SizedBox(height:15),
          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4),
              side: BorderSide(
                color: Colors.grey
              )),
            clipBehavior: Clip.antiAliasWithSaveLayer,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(15),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Image.network("https://upload.wikimedia.org/wikipedia/commons/thumb/d/d8/Person_icon_BLACK-01.svg/800px-Person_icon_BLACK-01.svg.png?20180306142558",
                        height: 100, width: 100, fit: BoxFit.cover,
                      ),
                      Container(width: 20),
                      Expanded(
                        child: Column(
                          crossAxisAlignment : CrossAxisAlignment.start,
                          children: <Widget>[
                            SizedBox(height: 5),
                            Text("Rata - Rata Umur Responden", style: TextStyle(
                              color: Color.fromARGB(255, 88, 88, 88),
                              fontSize: 20,
                              fontWeight: FontWeight.bold
                            )),
                            SizedBox(height: 10),
                            Text("Rata-rata : 21", style: TextStyle(
                              color: Colors.grey,
                              fontSize: 18,
                              fontWeight: FontWeight.bold
                            )),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height:15),
            Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4),
              side: BorderSide(
                color: Colors.grey
              )),
            clipBehavior: Clip.antiAliasWithSaveLayer,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(15),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Image.network("https://cdn-icons-png.flaticon.com/512/3751/3751928.png",
                        height: 100, width: 100, fit: BoxFit.cover,
                      ),
                      Container(width: 20),
                      Expanded(
                        child: Column(
                          crossAxisAlignment : CrossAxisAlignment.start,
                          children: <Widget>[
                            SizedBox(height: 5),
                            Text("Rata - Rata GPA Responden", style: TextStyle(
                              color: Color.fromARGB(255, 88, 88, 88),
                              fontSize: 20,
                              fontWeight: FontWeight.bold
                            )),
                            SizedBox(height: 10),
                            Text("Rata - Rata : 3.5", style: TextStyle(
                              color: Colors.grey,
                              fontSize: 18,
                              fontWeight: FontWeight.bold
                            )),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height:15),
            SizedBox(
              height: 100,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(child: AverageItem(title: "Total Responden", value: 10)),
                  Expanded(child: AverageItem(title: "Jumlah Kategori", value: 10)),
                ],
              ),
            ),
            SizedBox(height:15),
            const SizedBox(
              height: 20,
              child: Text('Responden Berdasarkan Gender',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.left,
              ),
            ),
            SizedBox(
              height: 200,
              child: Stack(
                children: [
                  PieChart(
                    PieChartData(
                      sectionsSpace: 0,
                      centerSpaceRadius: 40,
                      sections: showingSections(),
                    ),
                  ),
                  Positioned(
                    right: 25,
                    top: 50,
                    child: Column(
                      children: [
                        _buildLegendItem(const Color.fromARGB(255, 104, 2, 238), 'Perempuan'),
                        _buildLegendItem(const Color.fromARGB(255, 171, 131, 226), 'Laki-Laki'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height:15),
            SizedBox(
              height: 28,
              child: Center(
                child: Text(
                  'Responden Berdasarkan Negara',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            SizedBox(height:15),
            SizedBox(
              height: 200,
              child: ListView(
                scrollDirection: Axis.vertical,
                children: const [
                  ListItem(title: "Item 1"),
                  ListItem(title: "Item 2"),
                  ListItem(title: "Item 3"),
                  ListItem(title: "Item 4"),
                  ListItem(title: "Item 5"),
                ],
              ),
            ),
            SizedBox(height:25),
            ElevatedButton(
              child: Text("Go To Detail ->"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color.fromARGB(255, 235, 124, 255),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(color: Colors.grey)
                )
              ),
              onPressed: (){
                Navigator.push(context, 
                MaterialPageRoute(builder: (context) => Detail())
                );
              },
            )
          ]
        )
      )
    );
  }
}

//List untuk Data PieChart
List<PieChartSectionData> showingSections() {
  return [
    PieChartSectionData(
      color: const Color.fromARGB(255, 104, 2, 238),
      value: 55,
      title: '55%',
      radius: 60,
      titleStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xffffffff)),
    ),
    PieChartSectionData(
      color: const Color.fromARGB(255, 171, 131, 226),
      value: 45,
      title: '45%',
      radius: 50,
      titleStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xffffffff)),
    ),
  ];
}

//Widget untuk mengatur nama item PieChart
Widget _buildLegendItem(Color color, String label) {
  return Row(
    children: [
      Container(
        width: 10,
        height: 10,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
        ),
      ),
      const SizedBox(width: 4),
      Text(label),
    ],
  );
}

//Class untuk menampilkan Rata - rata Item
class AverageItem extends StatelessWidget {
  const AverageItem({
    super.key,
    required this.title,
    required this.value,
  });

  final String title;
  final double value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4.0),
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              blurRadius: 16,
              spreadRadius: -5,
              color: Colors.black.withOpacity(0.15),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 16,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

//Class untuk menampilkan daftar Item pada bagian Berdasar Negara
class ListItem extends StatelessWidget {
  const ListItem({
    super.key,
    required this.title,
  });

  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4.0),
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              blurRadius: 16,
              spreadRadius: -5,
              color: Colors.black.withOpacity(0.15),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 12,
                ),
              ),
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}